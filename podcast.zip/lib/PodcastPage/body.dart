import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../screens/author.dart';
import '../utils/colors.dart';
import '../widgets/back_arrow.dart';
import '../widgets/background.dart';
import '../widgets/bottom_bar.dart';
import 'podcast_episode.dart';

class Body extends StatefulWidget {
  const Body({Key? key, required this.userId}) : super(key: key);

  final String userId;
  @override
  State<Body> createState() => _BodyState();
}

class _BodyState extends State<Body> {
  bool isExpanded = true;
  bool isExpanded2 = true;
  late ScrollController _scrollController;

  bool _isScrolled = false;

  @override
  void initState() {
    _scrollController = ScrollController();
    _scrollController.addListener(_listenToScrollChange);

    super.initState();
  }

  void _listenToScrollChange() {
    if (_scrollController.offset >= 50.0) {
      setState(() {
        _isScrolled = true;
      });
    } else {
      setState(() {
        _isScrolled = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    CollectionReference podcast =
        FirebaseFirestore.instance.collection('Popular Podcast');

    return Background(
      child: Stack(
        children: [
          FutureBuilder(
            future: podcast.doc(widget.userId).get(),
            builder: (BuildContext context, AsyncSnapshot<dynamic> snapshot) {
              // if (snapshot.connectionState == ConnectionState.done) {
              //
              // }
              Map<String, dynamic> data =
                  snapshot.data!.data() as Map<String, dynamic>;

              return Container(
                child: Column(
                  children: [
                    Expanded(
                      child: InkWell(
                        highlightColor: Colors.transparent,
                        splashColor: Colors.transparent,
                        onTap: () {
                          setState(() {
                            isExpanded = !isExpanded;
                          });
                        },
                        child: AnimatedContainer(
                          margin: EdgeInsets.all(10),
                          curve: Curves.easeOutCirc,
                          duration: Duration(milliseconds: 700),
                          decoration: BoxDecoration(
                            color: AppColors.backgroundColor,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.lightgrey.withOpacity(0.7),
                                blurRadius: 10,
                                offset: Offset(7, 7),
                              ),
                            ],
                            borderRadius: BorderRadius.all(
                              Radius.circular(30),
                            ),
                          ),
                          child: Stack(
                            children: [
                              ColorFiltered(
                                colorFilter: ColorFilter.mode(
                                    AppColors.backgroundColor, BlendMode.color),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(30),
                                    image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: NetworkImage(
                                        "${data['image']}",
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned.fill(
                                child: BackdropFilter(
                                  filter:
                                      ImageFilter.blur(sigmaY: 5, sigmaX: 5),
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(30),
                                      color:
                                          AppColors.lightgrey.withOpacity(0.70),
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 20),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.stretch,
                                  children: [
                                    Row(
                                      children: [
                                        BackArrow(
                                          borderColor: AppColors.lightgrey,
                                          iconColor: AppColors.whiteColor,
                                          press: () {
                                            /*Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) {
                                                  return AudioPage();
                                                },
                                              ),
                                            );*/
                                          },
                                        ),
                                        SizedBox(
                                          width: size.width * 0.7,
                                        )
                                      ],
                                    ),
                                    Center(
                                      child: Column(
                                        children: [
                                          Container(
                                            height: 100,
                                            width: 100,
                                            decoration: BoxDecoration(
                                              color: AppColors.containerone,
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              image: DecorationImage(
                                                fit: BoxFit.fill,
                                                image: NetworkImage(
                                                  "${data['image']}",
                                                ),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Text(
                                            "${data['name']}",
                                            style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                            maxLines: 2,
                                            textAlign: TextAlign.center,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          GestureDetector(
                                            onTap: () {
                                              Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) {
                                                    return AuthorPage();
                                                  },
                                                ),
                                              );
                                            },
                                            child: Container(
                                              decoration: BoxDecoration(
                                                border: Border(
                                                  bottom: BorderSide(
                                                      width: 2,
                                                      color: Colors.white54),
                                                ),
                                              ),
                                              child: Text(
                                                "${data['podcast_author']}",
                                                style: TextStyle(
                                                  fontSize: 14,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white54,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Container(
                                                width: size.width * 0.48,
                                                height: size.width * 0.11,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  gradient: LinearGradient(
                                                    colors: [
                                                      AppColors.containerone
                                                          .withOpacity(0.80),
                                                      AppColors.containertwo,
                                                      AppColors.containerthree
                                                          .withOpacity(0.90),
                                                    ],
                                                    stops: [
                                                      0.03,
                                                      0.4,
                                                      0.6,
                                                    ],
                                                    begin: Alignment.topLeft,
                                                    end: Alignment.bottomRight,
                                                  ),
                                                ),
                                                child: Center(
                                                  child: Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons.add,
                                                        color: Colors.white,
                                                        size: 22,
                                                      ),
                                                      SizedBox(
                                                        width: 10,
                                                      ),
                                                      Text(
                                                        "Follow",
                                                        style: TextStyle(
                                                          fontSize: 18,
                                                          fontWeight:
                                                              FontWeight.w600,
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Container(
                                                width: size.width * 0.1,
                                                height: size.width * 0.11,
                                                decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                  border: Border.all(
                                                      color: Colors.white54,
                                                      width: 1),
                                                ),
                                                child: Icon(
                                                  Icons.share_outlined,
                                                  color: Colors.white,
                                                  size: 22,
                                                ),
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Text(
                                            "${data['description']}",
                                            maxLines: isExpanded ? 3 : 10,
                                            softWrap: true,
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: 18,
                                              height: 2,
                                              fontWeight: FontWeight.bold,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    InkWell(
                      highlightColor: Colors.transparent,
                      splashColor: Colors.transparent,
                      onTap: () {},
                      child: AnimatedContainer(
                        height: isExpanded
                            ? size.height * 0.45
                            : size.height * 0.23,
                        curve: Curves.easeOutCirc,
                        duration: Duration(milliseconds: 700),
                        decoration: BoxDecoration(
                          color: AppColors.backgroundColor,
                        ),
                        child: CustomScrollView(
                          controller: _scrollController,
                          physics: BouncingScrollPhysics(),
                          slivers: [
                            SliverList(
                              delegate: SliverChildListDelegate(
                                [
                                  Podcast_Episode(
                                    size: size,
                                    userId: widget.userId,
                                    image: "${data['image']}",
                                  ),
                                  /*Podcast_Episode(
                                      size: size,
                                      press: () {
                                        _handleFABPressed();
                                      },
                                    ),
                                    Podcast_Episode(
                                      size: size,
                                      press: () {
                                        _handleFABPressed();
                                      },
                                    ),
                                    Podcast_Episode(
                                      size: size,
                                      press: () {
                                        _handleFABPressed();
                                      },
                                    ),
                                    Podcast_Episode(
                                      size: size,
                                      press: () {
                                        _handleFABPressed();
                                      },
                                    ),
                                    Podcast_Episode(
                                      size: size,
                                      press: () {
                                        _handleFABPressed();
                                      },
                                    ),
                                    Podcast_Episode(
                                      size: size,
                                      press: () {
                                        _handleFABPressed();
                                      },
                                    ),
                                    Podcast_Episode(
                                      size: size,
                                      press: () {
                                        _handleFABPressed();
                                      },
                                    ),*/
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
          BottomBar(),
        ],
      ),
    );
  }

  /*void _handleFABPressed() {
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      context: context,
      isScrollControlled: true,
      builder: (context) => Podcast_Popover(),
    );
  }*/
}
