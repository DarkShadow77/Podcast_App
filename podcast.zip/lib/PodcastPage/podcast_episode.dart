import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../screens/audio.dart';
import '../utils/colors.dart';
import '../widgets/play_button.dart';
import '../widgets/podcast_popover.dart';

class Podcast_Episode extends StatelessWidget {
  const Podcast_Episode({
    Key? key,
    required this.size,
    required this.userId,
    required this.image,
  }) : super(key: key);

  final Size size;
  final String userId;
  final String image;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: size.height * 0.80,
      child: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('Popular Podcast')
            .doc(userId)
            .collection('podcast_episode')
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> streamSnapshot) {
          if (streamSnapshot.hasData) {
            return Container(
              child: ListView.builder(
                itemCount: streamSnapshot.data!.docs.length,
                physics: BouncingScrollPhysics(),
                itemBuilder: (context, index) {
                  final DocumentSnapshot documentSnapshot =
                      streamSnapshot.data!.docs[index];
                  return OutlinedButton(
                    onPressed: () {
                      showModalBottomSheet(
                        backgroundColor: Colors.transparent,
                        context: context,
                        isScrollControlled: true,
                        builder: (context) => Podcast_Popover(
                          documentSnapshot: documentSnapshot,
                        ),
                      );
                    },
                    child: Container(
                      padding: EdgeInsets.only(top: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: Text(
                              documentSnapshot['name'],
                              maxLines: 2,
                              style: TextStyle(
                                overflow: TextOverflow.ellipsis,
                                fontSize: 18,
                                color: Colors.white,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Padding(
                            padding: const EdgeInsets.only(right: 20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Container(
                                  width: size.width * 0.70,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        documentSnapshot['description'],
                                        maxLines: 2,
                                        style: TextStyle(
                                          color: AppColors.lightgrey,
                                          fontSize: 14,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      SizedBox(
                                        height: 5,
                                      ),
                                      Row(
                                        children: [
                                          Row(
                                            children: [
                                              Icon(
                                                Icons.timelapse,
                                                color: AppColors.lightgrey,
                                                size: 16,
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Text(
                                                documentSnapshot['timespan'],
                                                style: TextStyle(
                                                  color: AppColors.lightgrey,
                                                  fontSize: 14,
                                                ),
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            width: 40,
                                          ),
                                          Row(
                                            children: [
                                              Icon(
                                                Icons.date_range_rounded,
                                                color: AppColors.lightgrey,
                                                size: 16,
                                              ),
                                              SizedBox(
                                                width: 5,
                                              ),
                                              Text(
                                                documentSnapshot['date'],
                                                style: TextStyle(
                                                  color: AppColors.lightgrey,
                                                  fontSize: 14,
                                                ),
                                              )
                                            ],
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          return AudioPage(
                                            name: documentSnapshot['name'],
                                            date: documentSnapshot['date'],
                                            description:
                                                documentSnapshot['description'],
                                            timespan:
                                                documentSnapshot['timespan'],
                                            podcast_name: documentSnapshot[
                                                'podcast_name'],
                                            podcast_url:
                                                documentSnapshot['podcast_url'],
                                            podcast_image: image,
                                          );
                                        },
                                      ),
                                    );
                                  },
                                  child: PlayButton(
                                    diameter: 40,
                                    iconsize: 25,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Divider(
                            color: AppColors.lightgrey,
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            );
          }
          return const Center();
        },
      ),
    );
  }
}
