import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:perfect_volume_control/perfect_volume_control.dart';
import 'package:podcast/AudioPage/options_popover.dart';
import 'package:podcast/AudioPage/playback_popover.dart';
import 'package:podcast/utils/colors.dart';
import 'package:sleek_circular_slider/sleek_circular_slider.dart';

import '../widgets/add_playlist_popover.dart';
import '../widgets/back_arrow.dart';
import '../widgets/background.dart';
import '../widgets/custom_draw.dart';
import '../widgets/pause_button.dart';
import '../widgets/play_button.dart';

class Body extends StatefulWidget {
  const Body({
    Key? key,
    required this.name,
    required this.podcast_name,
    required this.podcast_url,
    required this.podcast_image,
    required this.date,
    required this.description,
    required this.timespan,
  }) : super(key: key);

  final String name;
  final String date;
  final String description;
  final String timespan;
  final String podcast_name;
  final String podcast_url;
  final String podcast_image;

  @override
  State<Body> createState() => _BodyState();
}

class _BodyState extends State<Body> {
  final audioPlayer = AudioPlayer();
  bool isPlaying = false;
  Duration duration = Duration.zero;
  Duration position = Duration.zero;

  double currentVol = 0.5;
  Color muteColor = Colors.white30;
  Color volumeColor = Colors.white;

  int audioPlayback = 1;

  @override
  void initState() {
    super.initState();

    setAudio();

    PerfectVolumeControl.hideUI =
        true; //set if system UI is hided or not on volume up/down
    Future.delayed(Duration.zero, () async {
      currentVol = await PerfectVolumeControl.getVolume();
      setState(() {
        //refresh UI
      });
    });

    PerfectVolumeControl.stream.listen((volume) {
      setState(() {
        currentVol = volume;
      });
    });

    audioPlayer.onPlayerStateChanged.listen((state) {
      setState(() {
        isPlaying = state == PlayerState.PLAYING;
      });
    });

    audioPlayer.setPlaybackRate(audioPlayback.toDouble());

    audioPlayer.onDurationChanged.listen((newDuration) {
      setState(() {
        duration = newDuration;
      });
    });

    audioPlayer.onAudioPositionChanged.listen((newPosition) {
      setState(() {
        position = newPosition;
      });
    });
  }

  Future setAudio() async {
    String url = widget.podcast_url;
    audioPlayer.setUrl(url);
  }

  @override
  void dispose() {
    audioPlayer.dispose();
    // TODO: implement dispose
    super.dispose();
  }

  String formatTime(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final hours = twoDigits(duration.inHours);
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));

    return [
      if (duration.inHours > 0) hours,
      minutes,
      seconds,
    ].join(':');
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Background(
      child: Container(
        child: Stack(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      BackArrow(
                        borderColor: Colors.white,
                        iconColor: Colors.white,
                        press: () {
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (context) {
                          //       return PodcastPage();
                          //     },
                          //   ),
                          // );
                        },
                      ),
                      IconButton(
                        icon: Icon(
                          Icons.more_vert_rounded,
                          color: Colors.white,
                          size: 35,
                        ),
                        onPressed: () {
                          Map<String, dynamic> userInfoMap = {
                            "name": widget.name,
                            "podcast_name": widget.podcast_name,
                            "podcast_url": widget.podcast_url,
                            "podcast_image": widget.podcast_image,
                            "date": widget.date,
                            "description": widget.description,
                            "timespan": widget.timespan,
                          };
                          _optionHandleFABPressed(userInfoMap);
                        },
                      )
                    ],
                  ),
                ),
                Container(
                  margin: EdgeInsets.only(bottom: 40),
                  width: 300,
                  height: 300,
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Color(0xff171925),
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 10),
                          padding: EdgeInsets.only(bottom: 40),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Icon(
                                CupertinoIcons.volume_off,
                                color: muteColor,
                                size: 18,
                              ),
                              Icon(
                                CupertinoIcons.speaker_2_fill,
                                color: volumeColor,
                                size: 18,
                              ),
                            ],
                          ),
                        ),
                      ),
                      Container(
                        margin: EdgeInsets.all(12),
                        child: RotatedBox(quarterTurns: 2, child: CustomArc()),
                      ),
                      Container(
                        padding: EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                        ),
                        child: Stack(
                          children: [
                            SleekCircularSlider(
                              min: 0,
                              max: 1,
                              appearance: CircularSliderAppearance(
                                size: 250,
                                angleRange: 180,
                                startAngle: 180,
                                counterClockwise: true,
                                customWidths: CustomSliderWidths(
                                  progressBarWidth: 5,
                                  trackWidth: 5,
                                  handlerSize: 10,
                                ),
                                customColors: CustomSliderColors(
                                  trackColor: Colors.white38,
                                  progressBarColors: [
                                    Color(0xfff25656),
                                    Color(0xff985ee1),
                                  ],
                                  hideShadow: true,
                                  gradientStartAngle: 120,
                                  dotColor: Colors.white,
                                ),
                              ),
                              initialValue: currentVol,
                              onChange: (double value) {
                                currentVol = value;
                                PerfectVolumeControl.setVolume(
                                    currentVol); //set new volume
                                setState(() {});
                              },
                            ),
                            Container(
                              margin: EdgeInsets.all(15),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Color(0xff181A27),
                              ),
                              child: Container(
                                padding: EdgeInsets.all(10),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xff181A27),
                                ),
                                child: Container(
                                  padding: EdgeInsets.all(2),
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: Color(0xff6B4399),
                                    image: DecorationImage(
                                      fit: BoxFit.fill,
                                      image: NetworkImage(widget.podcast_image),
                                    ),
                                  ),
                                  child: Container(
                                    padding: EdgeInsets.all(65),
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(
                                        width: 1,
                                        color: Colors.white.withOpacity(0.25),
                                      ),
                                    ),
                                    child: Container(
                                      padding: EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: Colors.black38,
                                        border: Border.all(
                                          width: 0.5,
                                          color: Colors.white54,
                                        ),
                                      ),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: AppColors.backgroundColor,
                                          border: Border.all(
                                            width: 0.5,
                                            color: Colors.white60,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 30),
                  child: Container(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: size.width * 0.45,
                              child: Text(
                                widget.name,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 24,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            SizedBox(
                              width: size.width * 0.50,
                              child: Text(
                                widget.podcast_name,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.50),
                                  fontSize: 18,
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Container(
                              width: 25,
                              height: 25,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image: AssetImage("assets/downloading.png"),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 30,
                            ),
                            Container(
                              width: 25,
                              height: 25,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.fill,
                                  image: AssetImage("assets/like.png"),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Slider(
                  activeColor: AppColors.containerthree.withOpacity(0.50),
                  inactiveColor: Colors.white10,
                  thumbColor: AppColors.containertwo,
                  min: 0,
                  max: duration.inSeconds.toDouble(),
                  value: position.inSeconds.toDouble(),
                  onChanged: (value) async {
                    final position = Duration(seconds: value.toInt());
                    await audioPlayer.seek(position);

                    await audioPlayer.resume();
                  },
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        formatTime(position),
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 19,
                        ),
                      ),
                      SizedBox(
                        width: 2,
                      ),
                      Text(
                        '/',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.50),
                          fontSize: 14,
                        ),
                      ),
                      SizedBox(
                        width: 2,
                      ),
                      Text(
                        formatTime(duration),
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.50),
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(vertical: 20, horizontal: 30),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            fit: BoxFit.fill,
                            image: AssetImage("assets/previous.png"),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () async {
                          if (isPlaying) {
                            await audioPlayer.pause();
                          } else {
                            await audioPlayer.resume();
                          }
                        },
                        child: isPlaying
                            ? PauseButton()
                            : PlayButton(
                                diameter: 62,
                                iconsize: 40,
                              ),
                      ),
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            fit: BoxFit.fill,
                            image: AssetImage("assets/next.png"),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Container(
                  padding: EdgeInsets.symmetric(
                    vertical: 10,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      OutlinedButton(
                        onPressed: () {
                          Map<String, dynamic> userInfoMap = {
                            "name": widget.name,
                            "podcast_name": widget.podcast_name,
                            "podcast_url": widget.podcast_url,
                            "podcast_image": widget.podcast_image,
                            "date": widget.date,
                            "description": widget.description,
                            "timespan": widget.timespan,
                          };
                          _addPlaylistHandleFABPressed(userInfoMap);
                        },
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(
                            color: Colors.transparent,
                          ),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Center(
                              child: Container(
                                height: 25,
                                width: 25,
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    image: AssetImage(
                                        "assets/images/add-playlist.png"),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                            Text(
                              "Add to Playlist",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 20,
                      ),
                      Row(
                        children: [
                          OutlinedButton(
                            onPressed: () {
                              _playbackHandleFABPressed();
                            },
                            style: OutlinedButton.styleFrom(
                              minimumSize: Size.zero,
                              padding: EdgeInsets.all(10),
                              backgroundColor: Color(0xff464660),
                              side: BorderSide(
                                color: Colors.transparent,
                              ),
                            ),
                            child: Row(
                              children: [
                                Text(
                                  "X",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                  ),
                                ),
                                SizedBox(
                                  width: 3,
                                ),
                                Text(
                                  audioPlayback.toString(),
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                  ),
                                ),
                                SizedBox(
                                  width: 3,
                                ),
                                RotatedBox(
                                  quarterTurns: 1,
                                  child: Icon(
                                    Icons.arrow_forward_ios_rounded,
                                    color: Colors.white,
                                    size: 10,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "Playback Speed",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Center(
                child: Container(
                  width: 70,
                  height: 50,
                  decoration: BoxDecoration(
                    color: Color(0xff464660),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(12),
                      topRight: Radius.circular(12),
                    ),
                  ),
                  child: ShaderMask(
                    blendMode: BlendMode.srcATop,
                    shaderCallback: (bounds) => LinearGradient(
                      colors: [
                        Colors.white,
                        Colors.white.withOpacity(0.50),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      stops: [
                        0.5,
                        0.5,
                      ],
                    ).createShader(bounds),
                    child: Icon(
                      Icons.keyboard_double_arrow_up_rounded,
                      size: 30,
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  void _optionHandleFABPressed(Map<String, dynamic> userInfoMap) {
    Map<String, dynamic> podcastData = {
      "name": widget.name,
      "podcast_name": widget.podcast_name,
      "podcast_url": widget.podcast_url,
      "podcast_image": widget.podcast_image,
      "date": widget.date,
      "description": widget.description,
      "timespan": widget.timespan,
    };
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      context: context,
      isScrollControlled: true,
      builder: (context) => OptionPopover(
        podcastData: podcastData,
      ),
    );
  }

  void _addPlaylistHandleFABPressed(Map<String, dynamic> userInfoMap) {
    Map<String, dynamic> podcastData = {
      "name": widget.name,
      "podcast_name": widget.podcast_name,
      "podcast_url": widget.podcast_url,
      "podcast_image": widget.podcast_image,
      "date": widget.date,
      "description": widget.description,
      "timespan": widget.timespan,
    };
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      context: context,
      isScrollControlled: true,
      builder: (context) => AddPlaylistPopover(
        podcastData: podcastData,
      ),
    );
  }

  void _playbackHandleFABPressed() {
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      context: context,
      isScrollControlled: true,
      builder: (context) => PlaybackPopover(
        firstPress: () {
          setState(() {
            audioPlayback = 1;
            Navigator.of(context).pop();
          });
        },
        secondPress: () {
          setState(() {
            audioPlayback = 2;
            Navigator.of(context).pop();
          });
        },
        thirdPress: () {
          setState(() {
            audioPlayback = 3;
            Navigator.of(context).pop();
          });
        },
        fourthPress: () {
          setState(() {
            audioPlayback = 4;
            Navigator.of(context).pop();
          });
        },
        fifthPress: () {
          setState(() {
            audioPlayback = 5;
            Navigator.of(context).pop();
          });
        },
      ),
    );
  }
}
