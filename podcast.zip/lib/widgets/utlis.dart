import 'package:flutter/material.dart';

const Color kScaffoldBackgroundColor = Color(0xffbac4cf);
const double kDiameter = 300;
