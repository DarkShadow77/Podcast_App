import 'package:flutter/material.dart';

import '../utils/colors.dart';

class CreatePlaylistPopover extends StatelessWidget {
  CreatePlaylistPopover({
    Key? key,
  }) : super(key: key);

  final formKey = GlobalKey<FormState>();
  final playlistController = TextEditingController();

  @override
  void dispose() {
    playlistController.dispose();
    // TODO: implement dispose
    dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => Navigator.of(context).pop(),
      child: Stack(
        children: [
          Container(
            margin: const EdgeInsets.all(10.0),
            padding: const EdgeInsets.only(
                right: 20.0, left: 20.0, top: 80.0, bottom: 20.0),
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: AppColors.darkgrey,
              borderRadius: const BorderRadius.all(Radius.circular(30.0)),
            ),
            child: ListView(
              physics: BouncingScrollPhysics(),
              children: [
                Container(
                  child: Column(
                    children: [
                      SizedBox(
                        height: 40,
                      ),
                      Form(
                        key: formKey,
                        child: TextFormField(
                          controller: playlistController,
                          cursorColor: Colors.white,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                  color: AppColors.containerone, width: 2.0),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(
                                  color: Color(0xff66687a), width: 2.0),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              gapPadding: 8,
                            ),
                            hintText: "Enter Your Playlist Name",
                            hintStyle: TextStyle(
                              fontSize: 18,
                              color: Color(0xff9394ad),
                            ),
                            floatingLabelBehavior: FloatingLabelBehavior.always,
                            prefixIcon: Icon(
                              Icons.email_outlined,
                              color: Colors.transparent,
                              size: 10,
                            ),
                          ),
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.white,
                          ),
                          autovalidateMode: AutovalidateMode.onUserInteraction,
                          validator: (user) => user != null && user.length < 2
                              ? 'Enter min. 2 character'
                              : null,
                        ),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  _buildHandle(context),
                  Text(
                    "Create a New Playlist",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  SizedBox(
                    width: 200,
                    child: Text(
                      "Choose your preferred playlist to add your podcast",
                      style: TextStyle(
                        fontSize: 15,
                        color: Color(0xff545568),
                      ),
                      maxLines: 2,
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildHandle(BuildContext context) {
    return FractionallySizedBox(
      widthFactor: 0.20,
      child: Container(
        margin: const EdgeInsets.symmetric(
          vertical: 15.0,
        ),
        child: Container(
          height: 5.0,
          decoration: BoxDecoration(
            color: Color(0xff1f212e),
            borderRadius: const BorderRadius.all(Radius.circular(2.5)),
          ),
        ),
      ),
    );
  }
}
