import 'package:flutter/material.dart';

import '../AudioPage/body.dart';

class AudioPage extends StatefulWidget {
  const AudioPage(
      {Key? key,
      required this.name,
      required this.podcast_name,
      required this.podcast_url,
      required this.date,
      required this.description,
      required this.timespan,
      required this.podcast_image})
      : super(key: key);

  final String name;
  final String date;
  final String description;
  final String timespan;
  final String podcast_name;
  final String podcast_url;
  final String podcast_image;

  @override
  State<AudioPage> createState() => _AudioPageState();
}

class _AudioPageState extends State<AudioPage> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: SafeArea(
        child: Body(
          name: widget.name,
          date: widget.date,
          description: widget.description,
          timespan: widget.timespan,
          podcast_name: widget.podcast_name,
          podcast_url: widget.podcast_url,
          podcast_image: widget.podcast_image,
        ),
      ),
    );
  }
}
