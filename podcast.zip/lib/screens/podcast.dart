import 'package:flutter/material.dart';
import 'package:podcast/PodcastPage/body.dart';

class PodcastPage extends StatelessWidget {
  PodcastPage({
    Key? key,
    required this.userId,
  }) : super(key: key);

  final String userId;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: SafeArea(
        child: Body(
          userId: userId,
        ),
      ),
    );
  }
}
