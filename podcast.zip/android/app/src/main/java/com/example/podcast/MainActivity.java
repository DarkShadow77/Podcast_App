package com.example.podcast;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
